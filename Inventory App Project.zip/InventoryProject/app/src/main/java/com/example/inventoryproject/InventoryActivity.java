package com.example.inventoryproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.ListFragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.internal.NavigationMenu;

import java.util.List;

/**
 *  The InventoryActivity class implements the primary inventory fragment container activity
 * for use with the app
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class InventoryActivity extends AppCompatActivity
            implements AddItemDialogFragment.OnItemEnteredListener{
    // Declare class variables
    private ItemDatabase mItemDb;
    private ItemFragment mFragment;
    private final int REQUEST_CODE_NOTIFY = 0;

    /**
     * This is called when the activity is started. This method creates fragments based on
     * the itemDatabase elements on loading.
     *
     * @param savedInstanceState saved state of the activity when activity is paused or stopped.
     * @return (description of the return value)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Load database instance
        mItemDb = ItemDatabase.getInstance(getApplicationContext());

        // Setup FragmentManager to populate database items as fragments
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.item_fragment_container);

        // Retrieving and iterating through existing database items and creating fragments to show
        List<Item> Items = mItemDb.getItems();
        for(int i = 0; i < Items.size(); i++) {
            //Log.d("Item: ", Items.get(i).toString());
            fragment = new ItemFragment().newInstance(Items.get(i).getName(), Items.get(i).getCount());
            fragmentManager.beginTransaction()
                    .add(R.id.item_fragment_container, fragment)
                    .commit();
        }
    }

    // Create options menu in the app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_bar_menu, menu);
        return true;
    }

    /**
     * This method is called from AddItemDialogFragment when user enters a new item and count.
     * It creates and displays a new fragment based on the data entered, then passes that data
     * to create a new entry in the itemDatabase.
     *
     * @param itemName name of the item to be added, passed from AddItemDialogFragment
     * @param count count of the item to be added, passed from AddItemDialogFragment
     */
    public void onItemEntered(String itemName, int count){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        //Log.d("Passed value", itemName);
        if(itemName.length() > 0) {
            mItemDb = ItemDatabase.getInstance(getApplicationContext());
            Item item = new Item(itemName, count);
            mItemDb.addItem(item);
            //Log.d("Database Success?", "true");
            ItemFragment itemFragment = ItemFragment.newInstance(itemName, count);
            fragmentTransaction.add(R.id.item_fragment_container, itemFragment).commit();
            Toast.makeText(this, "Added " + itemName, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * This method handles the user's choice within the app bar.
     *
     * @param item Option chosen by the user in the app bar
     * @return returns boolean if it properly executes the option chosen.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add_item:
                FragmentManager fragmentManager = getSupportFragmentManager();
                AddItemDialogFragment dialog = new AddItemDialogFragment();
                dialog.show(fragmentManager, "addItemDialog");
                return true;

            case R.id.action_settings:
                Intent intent = new Intent(this, Options.class);
                startActivityForResult(intent, REQUEST_CODE_NOTIFY);
                return true;

            case R.id.action_quit:
                finish();
                System.exit(0);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}