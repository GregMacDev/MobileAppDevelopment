package com.example.inventoryproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 *  The ItemDatabase class implements the structure of the database holding the items and counts
 *  that are used in the app.
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class ItemDatabase extends SQLiteOpenHelper {

    private final static String TAG = "List Items";
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "items.db";

    private static ItemDatabase mItemDb;

    /**
     * This method retrieves an instance of the item database to work with in other activities
     *
     * @param context database context
     * @return and instance of the ItemDatabase
     */
    public static ItemDatabase getInstance(Context context){
        if (mItemDb == null){
            mItemDb = new ItemDatabase(context);
        }
        return mItemDb;
    }

    private ItemDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Declaration of the structure of the database table
    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String ITEM_ID = "_id";
        private static final String ITEM = "text";
        private static final String COUNT = "count";
    }

    /**
     * This method is called when the database is created and creates the structure of the data
     *
     * @param db the SQLite database
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Item table
        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.ITEM_ID + " integer primary key autoincrement, " +
                ItemTable.ITEM + " text, " +
                ItemTable.COUNT + " int)");
    }

    /**
     * This method updates the database from version to version
     *
     * @param db saved state of the activity when the activity is paused or stopped
     * @param oldVersion oldVersion of the database
     * @param newVersion newVersion of the database
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    /**
     * This method uses SQL commands to get all of the data from the database and stores it
     * in a list for use within the app.
     *
     * @return a list of entries of the items from the ItemDatabase
     */
    public List<Item> getItems(){
        List<Item> Items = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + ItemTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor.moveToFirst()) {
            do {
                //Log.d("Into Cursor Parse: ", "yes");
                Item item = new Item();
                item.setId(cursor.getInt(0));
                item.setName(cursor.getString(1));
                item.setCount(cursor.getInt(2));
                Items.add(item);
            }while (cursor.moveToNext());
        }
        //Log.d("Exit Cursor Parse: ", "yes");
        cursor.close();
        return Items;
    }

    /**
     * This method is called when adding an item to the database.
     *
     * @param item instance of the item to add to the database
     * @return returns the item id associated with the passed user.
     */
    public long addItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.ITEM, item.getName());
        values.put(ItemTable.COUNT, item.getCount());

        long itemId = db.insert(ItemTable.TABLE, null, values);
        //Log.d("ItemId", String.valueOf(itemId));
        return itemId;
    }

    /**
     * This method is called when the count of the item in the database needs updating.
     *
     * @param itemName the name of the item that needs updating
     * @param itemCount the count of the item to update.
     * @return returns boolean representing if an item was updated
     */
    public boolean updateItemCount(String itemName, int itemCount){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COUNT, itemCount);
        int rowsUpdated = db.update(ItemTable.TABLE, values, "text = ?",
                new String[] {itemName});
        return rowsUpdated > 0;
    }

    /**
     * This method is called when the user wants to delete an item from the database.
     *
     * @param itemName name of the item to be deleted.
     * @return returns boolean representing if an item was deleted
     */
    public boolean deleteItem(String itemName){
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(ItemTable.TABLE, ItemTable.ITEM + " = ?",
                new String[] {itemName});
        return rowsDeleted > 0;
    }
}
