package com.example.inventoryproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/**
 *  The MainActivity class implements the functions of the login screen.
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class MainActivity extends AppCompatActivity {

    private LoginDatabase mLoginDb;
    private EditText mUserNameEditText;
    private EditText mPasswordEditText;
    private long mUserId;
    private User user;

    /**
     * This method is called when the activity is started. It declares the edit texts and database
     * instance for use within the activity
     *
     * @param savedInstanceState saved state of the activity when the activity is paused or stopped
     * @return nothing
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user = new User();
        setContentView(R.layout.activity_main);

        mUserNameEditText = findViewById(R.id.userNameEditText);
        mPasswordEditText = findViewById(R.id.passwordEditText);
        mLoginDb = LoginDatabase.getInstance(getApplicationContext());
    }

    /**
     * this is the logic of clicking the sign in button. It checks the database for the
     * credentials entered and either allows the user to access the inventory or requests the user
     * create an account.
     *
     * @param view  the button view
     * @return nothing
     */
    public void onSignInClicked(View view) {
        user.setName(mUserNameEditText.toString());
        user.setPassword(mPasswordEditText.toString());
        if(mLoginDb.findUser(mUserNameEditText.toString(), mPasswordEditText.toString())){
            Intent intent = new Intent(this, InventoryActivity.class);
            startActivity(intent);
            finish();
        }
        else{
            Toast.makeText(MainActivity.this, "User not found. Please Create an Account", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * This method is called when the create account button is clicked. It sends the user
     * name and password to the database and adds it as a new account. It then prints to the screen,
     * via a toast, that the account was created. The user can then login.
     *
     * @param view the button view
     * @return nothing
     */
    public void onCreateClicked(View view){
        user.setName(mUserNameEditText.toString());
        user.setPassword(mPasswordEditText.toString());
        mLoginDb.addUser(user);
        Toast.makeText(MainActivity.this, "Account Created", Toast.LENGTH_LONG).show();
    }
}