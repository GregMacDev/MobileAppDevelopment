package com.example.inventoryproject;

/**
 *  The User class implements the structure of the User items used with the login database
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class User {
    private long mId;
    private String mName;
    private String mPassword;

    // default constructor
    public User() {}

    // standard constructor
    public User(String name, String password) {
        mName = name;
        mPassword = password;
    }

    //setters and getters for class variables
    public long getId(){
        return mId;
    }

    public void setId(long id){
        mId = id;
    }

    public String getName(){
        return mName;
    }

    public void setName(String name){
        mName = name;
    }

    public String getPassword(){
        return mPassword;
    }

    public void setPassword(String password){
        mPassword = password;
    }
}

