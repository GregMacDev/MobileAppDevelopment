package com.example.inventoryproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

/**
 *  The Options class implements the options activity for the app
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class Options extends AppCompatActivity {

    private Switch notificationsSwitch;
    private static final int SMS_PERMISSION_CODE = 100;

    /**
     * This method is called when the activity is started. It populates the options activity
     * with the options available. In this case, it populates a "notifications" switch and listens
     * for the change in state.
     *
     * @param savedInstanceState saved state of the activity when activity paused or stopped.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        notificationsSwitch = findViewById(R.id.notificationSwitch);
        notificationsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkPermission(Manifest.permission.SEND_SMS, SMS_PERMISSION_CODE);
                    //Log.d("Switch On", "true");
                }
                else {
                    //Log.d("Switch Off", "true");
                }
            }
        });
    }

    /**
     * Checks the permission granted by the program.
     *
     * @param permission system permission constant
     * @param requestCode the local code for the permission being requested.
     * @return boolean representing whether permission has been granted.
     */
    public boolean checkPermission(String permission, int requestCode) {

        // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(Options.this, permission)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[] {permission}, requestCode);
            return false;
        }
        else {
            Toast.makeText(this,"Permission already granted",
                    Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    /**
     * Shows what the permission status of the program is.
     *
     * @param requestCode the local code for the permission to check
     * @param permissions which permissions are available in this program
     * @param grantResults the result status of the permissions
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(Options.this,"SMS Permission Granted",
                        Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(Options.this,"SMS Permission Denied",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}