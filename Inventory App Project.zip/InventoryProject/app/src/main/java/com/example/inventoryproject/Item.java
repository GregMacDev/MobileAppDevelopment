package com.example.inventoryproject;

/**
 *  The Item class implements the structure of the items used with the Item database
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class Item {
    private long mId;
    private String mName;
    private int mCount;

    // default constructor
    public Item() {}

    // standard constructor
    public Item(String name, int count) {
        mName = name;
        mCount = count;
    }

    // Setters and getters for class variables
    public long getId(){
        return mId;
    }

    public void setId(long id){
        mId = id;
    }

    public String getName(){
        return mName;
    }

    public void setName(String name){
        mName = name;
    }

    public int getCount(){
        return mCount;
    }

    public void setCount(int count){
        mCount = count;
    }

    // Prints the values to the string. Used for debugging
    public String toString() {
        return "Id: " + mId + "\nItem Name: " + mName + "\nItem Count: " + mCount + "\n";
    }
}
