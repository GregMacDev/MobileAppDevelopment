package com.example.inventoryproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 *  The ItemFragment class implements the layout and functionality and creates the view of the
 *  fragment to display the data from the ItemDatabase.
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class ItemFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String NAME = "itemName";
    private static final String COUNT = "itemCount";


    // TODO: Rename and change types of parameters
    private String mItem;
    private List<Item> mItemList;
    private int mCount;
    private ItemDatabase mItemDb;
    private Options options;
    private static final int PERMISSION_RQST_SEND = 0;


    public ItemFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param itemName name of the Item for the new fragment instance
     * @param count    count of the item for the new fragment instance
     * @return A new instance of fragment ItemFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ItemFragment newInstance(String itemName, int count) {
        ItemFragment fragment = new ItemFragment();
        Bundle args = new Bundle();
        args.putString(NAME, itemName);
        args.putInt(COUNT, count);
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * This method is called when the activity is started. It initializes the database instance
     * and creates a list structure of the database items. If there's a saved state, mItem and
     * mCount get populated via the passed Bundle data.
     *
     * @param savedInstanceState saved state of the activity when the activity is paused or stopped
     * @return nothing
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        //Fragment fragment = fragmentManager.findFragmentById(R.id.item_fragment_container);
        mItemDb = ItemDatabase.getInstance(getActivity());
        mItemList = mItemDb.getItems();

        if (savedInstanceState != null) {
            mItem = savedInstanceState.getString(NAME);
            mCount = savedInstanceState.getInt(COUNT);
        }
    }

    /**
     * This method is called when the activity paused or stopped. Saves fragment data.
     *
     * @param outState saved state data
     * @return nothing
     */
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString(NAME, mItem);
        outState.putInt(COUNT, mCount);
    }

    /**
     * This method is called when the activity is started. It creates the view allowing the
     * fragment to show up in the container from ItemDatabase activity.
     *
     * @param inflater LayoutInflater to show the fragments.
     * @param container instance of the ViewGroup for the fragment
     * @param savedInstanceState data from the savedInstanceState from paused or stopped activity
     * @return the populated fragment.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_item, container, false);
        Item item = new Item();

        TextView itemText = view.findViewById(R.id.itemDescriptionText);
        TextView itemCount = view.findViewById(R.id.stockCountText);
        Button deleteButton = view.findViewById(R.id.deleteButton);
        Button plusButton = view.findViewById(R.id.plusButton);
        Button minusButton = view.findViewById(R.id.minusButton);

        Bundle args = getArguments();
        mItem = args.getString(NAME);
        mCount = args.getInt(COUNT);

        item.setName(mItem);
        item.setCount(mCount);

        // Logic for the delete button which removes fragment from view and deletes the item from
        // the database.
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.remove(ItemFragment.this).commit();
                mItemDb.deleteItem(item.getName());
            }
        });

        // Increases the number of items on hand when the plus button is clicked. The change is
        // sent to the database and the value is updated.
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCount++;
                itemCount.setText(String.valueOf(mCount));
                mItemDb.updateItemCount(item.getName(), mCount);
            }
        });

        // Decreases the number of items on hand when the minus button is clicked. The change is
        // sent to the database and the value is updated.
        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCount--;
                // Check for the value being 0. If it's greater than 0, update appropriately
                // if it is less than zero, set mCount to zero to prevent the item count from
                // becoming negative.
                if (mCount >= 0) {
                    itemCount.setText(String.valueOf(mCount));
                    mItemDb.updateItemCount(item.getName(), mCount);
                    if (mCount < 5) {
                        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

                            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.SEND_SMS)) {
                            } else {
                                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.SEND_SMS}, PERMISSION_RQST_SEND);
                            }
                        } else {
                            Toast.makeText(getContext(), "Low Inventory", Toast.LENGTH_LONG).show();
                        }
                    }
                    ;
                    // Sets the item count to zero when item count drops below zero.
                } else {
                    mCount = 0;
                }
                ;
            }
        });

        itemText.setText(mItem);
        itemCount.setText(String.valueOf(mCount));

        return view;
    }
}
