package com.example.inventoryproject;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

/**
 *  The AddItemDialogFragment class implements creation of a dialog allowing users to input
 *  data for adding new items to the item database.
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class AddItemDialogFragment extends DialogFragment{

    private ItemDatabase mItemDb;
    private EditText itemName;
    private EditText itemCount;
    private OnItemEnteredListener mListener;

    // Host activity must implement
    public interface OnItemEnteredListener {
        void onItemEntered(String itemName, int count);
    }

    /**
     * This method is called when the activity is started. It creates and manages the actions of
     * the AlertDialog for when a user needs to enter a new item into the app.
     *
     * @param savedInstanceState saved state of the activity when the activity is paused or stopped
     * @return building the AlerteDialog to enter a new item.
     */
    @Override
    public AlertDialog onCreateDialog(Bundle savedInstanceState) {

        mItemDb = ItemDatabase.getInstance(getActivity());

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = requireActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View view = inflater.inflate(R.layout.add_item_dialog_fragment, null);
        builder.setView(view)
                // Add action buttons
                .setPositiveButton("Create", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        itemName = view.findViewById(R.id.itemName);
                        itemCount = view.findViewById(R.id.itemCount);
                        String item = itemName.getText().toString();
                        int count = Integer.parseInt(itemCount.getText().toString());
                        mListener.onItemEntered(item.trim(), count);
                    }
                })
                .setNegativeButton("Cancel", null );
        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (OnItemEnteredListener) context;
    }
}

