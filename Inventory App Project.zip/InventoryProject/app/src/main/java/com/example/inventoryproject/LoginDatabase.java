package com.example.inventoryproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 *  The LoginDatabase class implements the structure of the database of the users' logins for access to the
 *  inventory app.
 *
 * @author  Greg MacPhelemy
 * @version 1.0
 * @since   02/19/21
 */

public class LoginDatabase extends SQLiteOpenHelper {
    private static final String TAG = "Login Users";
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "logins.db";

    private static LoginDatabase mLoginDb;

    /**
     * This method retrieves an instance of the login database to work with in other activities
     *
     * @param context database context
     * @return and instance of the LoginDatabase
     */
    public static LoginDatabase getInstance(Context context){
        if (mLoginDb == null){
            mLoginDb = new LoginDatabase(context);
        }
        return mLoginDb;
    }

    private LoginDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Declaration of the structure of the database table
    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String USER_ID = "_id";
        private static final String NAME = "name";
        private static final String PASSWORD = "password";
    }

    /**
     * This method is called when the database is created and creates the structure of the data
     *
     * @param db the SQLite database
     * @return nothing
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Login table
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.USER_ID + " integer primary key autoincrement, " +
                LoginTable.NAME + " text, " +
                LoginTable.PASSWORD + " int)");
    }

    /**
     * This method updates the database from version to version
     *
     * @param db saved state of the activity when the activity is paused or stopped
     * @param oldVersion oldVersion of the database
     * @param newVersion newVersion of the database
     * @return nothing
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    /**
     * This method uses SQL commands to get all of the data from the database and stores it
     * in a list for use within the app.
     *
     * @return a list of entries of the users from the LoginDatabase
     */
    public List<User> getUsers(){

        List<User> Users = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM " + LoginTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(cursor.getInt(0));
                user.setName(cursor.getString(1));
                user.setPassword(cursor.getString(2));
            }while (cursor.moveToNext());
        }
        cursor.close();
        //Log.d(TAG, Users.toString());
        return Users;
    }

    /**
     * This method attempts finds a user within the database by using SQL commands
     *
     * @param name name of the user trying to log in
     * @param password password entered by the user to login
     * @return boolean representing whether the user was found or not.
     */
    public boolean findUser(String name, String password){
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM " + LoginTable.TABLE + " WHERE " + LoginTable.NAME + " = '" + name +
                "' AND " + LoginTable.PASSWORD + " = '" + password + "'";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * This method is for adding a user to the database
     *
     * @param user instance of the user to add to the database
     * @return returns the user id associated with the passed user.
     */
    public long addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.NAME, user.getName() );
        values.put(LoginTable.PASSWORD, user.getPassword());

        long userId = db.insert(LoginTable.TABLE, null, values);
        //Log.d("ItemId", String.valueOf(userId));
        return userId;
    }
}
